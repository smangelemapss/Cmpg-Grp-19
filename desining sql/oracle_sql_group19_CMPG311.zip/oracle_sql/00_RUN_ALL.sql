-- =============================================================================
-- UBUNTU CAMPUS CLINIC — APPOINTMENT SYSTEM
-- Group 19 | CMPG 311 | DBMS Module | Physical Design
-- File: 00_RUN_ALL.sql
-- Purpose: Master script — run this ONE file in Oracle SQL Developer
--          to execute everything in the correct order
-- =============================================================================
--
-- HOW TO RUN:
--   1. Open Oracle SQL Developer
--   2. Connect to your Oracle schema
--   3. File > Open > select this file (00_RUN_ALL.sql)
--   4. Press F5 (Run Script) — NOT F9
--   5. Watch the Script Output tab at the bottom
--
-- =============================================================================

PROMPT ============================================================
PROMPT  UBUNTU CAMPUS CLINIC — Group 19 | CMPG 311
PROMPT  Starting full database setup...
PROMPT ============================================================

-- STEP 1: Create all 12 tables
PROMPT
PROMPT [STEP 1/4] Creating tables...
PROMPT
@@01_DDL/01_create_tables.sql

-- STEP 2: Create all indexes
PROMPT
PROMPT [STEP 2/4] Creating indexes...
PROMPT
@@01_DDL/02_create_indexes.sql

-- STEP 3: Create all views
PROMPT
PROMPT [STEP 3/4] Creating views...
PROMPT
@@01_DDL/03_create_views.sql

-- STEP 4: Insert all seed data
PROMPT
PROMPT [STEP 4/4] Inserting data...
PROMPT
@@02_DML/04_insert_data.sql

PROMPT
PROMPT ============================================================
PROMPT  Setup complete. Running verification checks...
PROMPT ============================================================

-- Final verification: table row counts
SELECT 'DEPARTMENT'      AS table_name, COUNT(*) AS row_count FROM DEPARTMENT      UNION ALL
SELECT 'STAFF',                          COUNT(*) FROM STAFF                         UNION ALL
SELECT 'DOCTOR',                         COUNT(*) FROM DOCTOR                        UNION ALL
SELECT 'PATIENT',                        COUNT(*) FROM PATIENT                       UNION ALL
SELECT 'PATIENT_CONTACT',               COUNT(*) FROM PATIENT_CONTACT               UNION ALL
SELECT 'USER_ACCOUNT',                  COUNT(*) FROM USER_ACCOUNT                  UNION ALL
SELECT 'TIMESLOT',                      COUNT(*) FROM TIMESLOT                      UNION ALL
SELECT 'APPOINTMENT',                   COUNT(*) FROM APPOINTMENT                   UNION ALL
SELECT 'QUEUE_ENTRY',                   COUNT(*) FROM QUEUE_ENTRY                   UNION ALL
SELECT 'MEDICAL_RECORD',               COUNT(*) FROM MEDICAL_RECORD               UNION ALL
SELECT 'NOTIFICATION',                 COUNT(*) FROM NOTIFICATION                 UNION ALL
SELECT 'AUDIT_LOG',                    COUNT(*) FROM AUDIT_LOG
ORDER BY 1;

-- Final verification: views
SELECT view_name FROM user_views
WHERE view_name LIKE 'VW_%'
ORDER BY view_name;

-- Final verification: indexes
SELECT index_name, table_name, uniqueness
FROM user_indexes
WHERE index_name LIKE 'IDX_%'
ORDER BY table_name, index_name;

PROMPT
PROMPT ============================================================
PROMPT  ALL DONE. Now open 04_queries/05_queries.sql and run
PROMPT  each query block individually with F9 to demonstrate.
PROMPT ============================================================
