-- =============================================================================
-- UBUNTU CAMPUS CLINIC — APPOINTMENT SYSTEM
-- Group 19 | CMPG 311 | DBMS Module | Physical Design
-- File: 01_create_tables.sql
-- Purpose: Create all 12 tables in FK dependency order
-- Database: Oracle SQL Developer
-- =============================================================================

-- Drop tables in reverse FK order (safe re-run)
DROP TABLE AUDIT_LOG         CASCADE CONSTRAINTS PURGE;
DROP TABLE NOTIFICATION      CASCADE CONSTRAINTS PURGE;
DROP TABLE MEDICAL_RECORD    CASCADE CONSTRAINTS PURGE;
DROP TABLE QUEUE_ENTRY       CASCADE CONSTRAINTS PURGE;
DROP TABLE APPOINTMENT       CASCADE CONSTRAINTS PURGE;
DROP TABLE USER_ACCOUNT      CASCADE CONSTRAINTS PURGE;
DROP TABLE DOCTOR            CASCADE CONSTRAINTS PURGE;
DROP TABLE PATIENT_CONTACT   CASCADE CONSTRAINTS PURGE;
DROP TABLE STAFF             CASCADE CONSTRAINTS PURGE;
DROP TABLE DEPARTMENT        CASCADE CONSTRAINTS PURGE;
DROP TABLE TIMESLOT          CASCADE CONSTRAINTS PURGE;
DROP TABLE PATIENT           CASCADE CONSTRAINTS PURGE;

-- =============================================================================
-- LEVEL 1 — No FK dependencies
-- =============================================================================

-- 1. PATIENT
CREATE TABLE PATIENT (
    patient_id        NUMBER          GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    student_number    VARCHAR2(10)    NOT NULL,
    first_name        VARCHAR2(100)   NOT NULL,
    last_name         VARCHAR2(100)   NOT NULL,
    email             VARCHAR2(254)   NOT NULL,
    contact_number    VARCHAR2(20)    NOT NULL,
    date_of_birth     DATE            NOT NULL,
    street            VARCHAR2(255)   NOT NULL,
    city              VARCHAR2(100)   NOT NULL,
    postal_code       VARCHAR2(10)    NOT NULL,
    consent_given     NUMBER(1)       DEFAULT 0 NOT NULL,
    registration_date TIMESTAMP       DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_patient         PRIMARY KEY (patient_id),
    CONSTRAINT uq_patient_stdnum  UNIQUE (student_number),
    CONSTRAINT uq_patient_email   UNIQUE (email),
    CONSTRAINT chk_consent        CHECK (consent_given IN (0, 1))
);

-- 2. TIMESLOT
CREATE TABLE TIMESLOT (
    slot_id      NUMBER        GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    slot_date    DATE          NOT NULL,
    start_time   VARCHAR2(8)   NOT NULL,
    end_time     VARCHAR2(8)   NOT NULL,
    is_available NUMBER(1)     DEFAULT 1 NOT NULL,
    CONSTRAINT pk_timeslot      PRIMARY KEY (slot_id),
    CONSTRAINT chk_slot_avail   CHECK (is_available IN (0, 1)),
    CONSTRAINT chk_slot_time    CHECK (end_time > start_time)
);

-- 3. DEPARTMENT (head_staff FK added after STAFF is created — see ALTER below)
CREATE TABLE DEPARTMENT (
    department_id   NUMBER        GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    department_name VARCHAR2(200) NOT NULL,
    head_staff_id   NUMBER,
    CONSTRAINT pk_department      PRIMARY KEY (department_id),
    CONSTRAINT uq_department_name UNIQUE (department_name)
);

-- =============================================================================
-- LEVEL 2 — Depends on Level 1
-- =============================================================================

-- 4. PATIENT_CONTACT
CREATE TABLE PATIENT_CONTACT (
    patient_contact_id NUMBER        GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    patient_id         NUMBER        NOT NULL,
    contact_name       VARCHAR2(150) NOT NULL,
    phone_number       VARCHAR2(20)  NOT NULL,
    relationship       VARCHAR2(100),
    CONSTRAINT pk_patient_contact PRIMARY KEY (patient_contact_id),
    CONSTRAINT fk_pc_patient      FOREIGN KEY (patient_id)
        REFERENCES PATIENT (patient_id) ON DELETE CASCADE
);

-- 5. STAFF
CREATE TABLE STAFF (
    staff_id             NUMBER       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    department_id        NUMBER,
    first_name           VARCHAR2(100) NOT NULL,
    last_name            VARCHAR2(100) NOT NULL,
    role                 VARCHAR2(20)  NOT NULL,
    email                VARCHAR2(254) NOT NULL,
    contact_number       VARCHAR2(20)  NOT NULL,
    working_hours_start  VARCHAR2(8)   NOT NULL,
    working_hours_end    VARCHAR2(8)   NOT NULL,
    CONSTRAINT pk_staff         PRIMARY KEY (staff_id),
    CONSTRAINT uq_staff_email   UNIQUE (email),
    CONSTRAINT chk_staff_role   CHECK (role IN ('DOCTOR', 'NURSE', 'ADMIN')),
    CONSTRAINT fk_staff_dept    FOREIGN KEY (department_id)
        REFERENCES DEPARTMENT (department_id) ON DELETE SET NULL
);

-- Now add the deferred FK on DEPARTMENT → STAFF
ALTER TABLE DEPARTMENT
    ADD CONSTRAINT fk_dept_head
    FOREIGN KEY (head_staff_id)
    REFERENCES STAFF (staff_id) ON DELETE SET NULL;

-- =============================================================================
-- LEVEL 3 — Depends on Level 2
-- =============================================================================

-- 6. DOCTOR (subtype of STAFF — PK is also FK)
CREATE TABLE DOCTOR (
    staff_id        NUMBER       NOT NULL,
    license_number  VARCHAR2(50) NOT NULL,
    specialisation  VARCHAR2(150) NOT NULL,
    CONSTRAINT pk_doctor         PRIMARY KEY (staff_id),
    CONSTRAINT uq_doctor_license UNIQUE (license_number),
    CONSTRAINT fk_doctor_staff   FOREIGN KEY (staff_id)
        REFERENCES STAFF (staff_id) ON DELETE CASCADE
);

-- 7. USER_ACCOUNT
CREATE TABLE USER_ACCOUNT (
    user_account_id NUMBER       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    username        VARCHAR2(150) NOT NULL,
    password_hash   VARCHAR2(255) NOT NULL,
    patient_id      NUMBER,
    staff_id        NUMBER,
    role            VARCHAR2(20)  NOT NULL,
    status          VARCHAR2(20)  DEFAULT 'ACTIVE' NOT NULL,
    CONSTRAINT pk_user_account          PRIMARY KEY (user_account_id),
    CONSTRAINT uq_username              UNIQUE (username),
    CONSTRAINT chk_user_role            CHECK (role IN ('PATIENT','DOCTOR','NURSE','ADMIN','RECEPTIONIST')),
    CONSTRAINT chk_user_status          CHECK (status IN ('ACTIVE','LOCKED','DISABLED')),
    CONSTRAINT chk_user_patient_or_staff CHECK (patient_id IS NOT NULL OR staff_id IS NOT NULL),
    CONSTRAINT fk_user_patient          FOREIGN KEY (patient_id)
        REFERENCES PATIENT (patient_id) ON DELETE CASCADE,
    CONSTRAINT fk_user_staff            FOREIGN KEY (staff_id)
        REFERENCES STAFF (staff_id) ON DELETE CASCADE
);

-- =============================================================================
-- LEVEL 4 — Depends on Level 3
-- =============================================================================

-- 8. APPOINTMENT
CREATE TABLE APPOINTMENT (
    appointment_id  NUMBER       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    slot_id         NUMBER       NOT NULL,
    patient_id      NUMBER       NOT NULL,
    staff_id        NUMBER       NOT NULL,
    status          VARCHAR2(20) DEFAULT 'SCHEDULED' NOT NULL,
    booking_type    VARCHAR2(20) DEFAULT 'SICK'      NOT NULL,
    priority        VARCHAR2(10) DEFAULT 'NORMAL'    NOT NULL,
    qr_code_token   VARCHAR2(36),
    CONSTRAINT pk_appointment       PRIMARY KEY (appointment_id),
    CONSTRAINT uq_appointment_slot  UNIQUE (slot_id),
    CONSTRAINT uq_appt_qr_token     UNIQUE (qr_code_token),
    CONSTRAINT chk_appt_status      CHECK (status IN ('SCHEDULED','CONFIRMED','COMPLETED','CANCELLED','NO_SHOW')),
    CONSTRAINT chk_appt_type        CHECK (booking_type IN ('SICK','FOLLOW_UP','WALK_IN','VIRTUAL_TRIAGE')),
    CONSTRAINT chk_appt_priority    CHECK (priority IN ('NORMAL','URGENT')),
    CONSTRAINT fk_appt_slot         FOREIGN KEY (slot_id)
        REFERENCES TIMESLOT (slot_id),
    CONSTRAINT fk_appt_patient      FOREIGN KEY (patient_id)
        REFERENCES PATIENT (patient_id),
    CONSTRAINT fk_appt_staff        FOREIGN KEY (staff_id)
        REFERENCES STAFF (staff_id)
);

-- 9. AUDIT_LOG
CREATE TABLE AUDIT_LOG (
    audit_log_id       NUMBER       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id            NUMBER       NOT NULL,
    action             VARCHAR2(10) NOT NULL,
    table_affected     VARCHAR2(100) NOT NULL,
    record_affected_id NUMBER       NOT NULL,
    log_timestamp      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip_address         VARCHAR2(45),
    CONSTRAINT pk_audit_log    PRIMARY KEY (audit_log_id),
    CONSTRAINT chk_audit_action CHECK (action IN ('CREATE','READ','UPDATE','DELETE')),
    CONSTRAINT fk_audit_user   FOREIGN KEY (user_id)
        REFERENCES USER_ACCOUNT (user_account_id)
);

-- =============================================================================
-- LEVEL 5 — Migrate last
-- =============================================================================

-- 10. QUEUE_ENTRY
CREATE TABLE QUEUE_ENTRY (
    queue_entry_id     NUMBER       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    appointment_id     NUMBER       NOT NULL,
    status             VARCHAR2(20) DEFAULT 'WAITING' NOT NULL,
    checked_in_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP NOT NULL,
    consult_start_time VARCHAR2(8),
    consult_end_time   VARCHAR2(8),
    room_number        VARCHAR2(50),
    CONSTRAINT pk_queue_entry      PRIMARY KEY (queue_entry_id),
    CONSTRAINT uq_queue_appt       UNIQUE (appointment_id),
    CONSTRAINT chk_queue_status    CHECK (status IN ('WAITING','IN_PROGRESS','COMPLETED','LEFT_WITHOUT_SEEN')),
    CONSTRAINT fk_queue_appt       FOREIGN KEY (appointment_id)
        REFERENCES APPOINTMENT (appointment_id)
);

-- 11. MEDICAL_RECORD
CREATE TABLE MEDICAL_RECORD (
    medical_record_id  NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    appointment_id     NUMBER NOT NULL,
    patient_id         NUMBER NOT NULL,
    diagnosis          VARCHAR2(4000),
    prescription       VARCHAR2(4000),
    treatment_notes    VARCHAR2(4000),
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_medical_record  PRIMARY KEY (medical_record_id),
    CONSTRAINT fk_mr_appointment  FOREIGN KEY (appointment_id)
        REFERENCES APPOINTMENT (appointment_id),
    CONSTRAINT fk_mr_patient      FOREIGN KEY (patient_id)
        REFERENCES PATIENT (patient_id)
);

-- 12. NOTIFICATION
CREATE TABLE NOTIFICATION (
    notification_id NUMBER       GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    patient_id      NUMBER,
    staff_id        NUMBER,
    appointment_id  NUMBER       NOT NULL,
    channel         VARCHAR2(10) NOT NULL,
    status          VARCHAR2(10) DEFAULT 'PENDING' NOT NULL,
    message         VARCHAR2(4000) NOT NULL,
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP NOT NULL,
    sent_at         TIMESTAMP,
    error_message   VARCHAR2(4000),
    CONSTRAINT pk_notification          PRIMARY KEY (notification_id),
    CONSTRAINT chk_notif_channel        CHECK (channel IN ('EMAIL','SMS')),
    CONSTRAINT chk_notif_status         CHECK (status IN ('PENDING','SENT','FAILED')),
    CONSTRAINT chk_notif_recipient      CHECK (patient_id IS NOT NULL OR staff_id IS NOT NULL),
    CONSTRAINT fk_notif_patient         FOREIGN KEY (patient_id)
        REFERENCES PATIENT (patient_id) ON DELETE SET NULL,
    CONSTRAINT fk_notif_staff           FOREIGN KEY (staff_id)
        REFERENCES STAFF (staff_id) ON DELETE SET NULL,
    CONSTRAINT fk_notif_appointment     FOREIGN KEY (appointment_id)
        REFERENCES APPOINTMENT (appointment_id) ON DELETE CASCADE
);

-- Confirm creation
SELECT table_name FROM user_tables
WHERE table_name IN (
    'PATIENT','PATIENT_CONTACT','TIMESLOT','DEPARTMENT',
    'STAFF','DOCTOR','USER_ACCOUNT','APPOINTMENT',
    'AUDIT_LOG','QUEUE_ENTRY','MEDICAL_RECORD','NOTIFICATION'
)
ORDER BY table_name;
