-- =============================================================================
-- UBUNTU CAMPUS CLINIC — APPOINTMENT SYSTEM
-- Group 19 | CMPG 311 | DBMS Module | Physical Design
-- File: 02_create_indexes.sql
-- Purpose: Create all performance and integrity indexes
-- =============================================================================

-- TIMESLOT: availability lookup by date (most frequent query in system)
CREATE INDEX idx_timeslot_date
    ON TIMESLOT (slot_date);

-- TIMESLOT: composite — available slots on a given date
CREATE INDEX idx_timeslot_date_avail
    ON TIMESLOT (slot_date, is_available);

-- APPOINTMENT: patient appointment history
CREATE INDEX idx_appt_patient
    ON APPOINTMENT (patient_id);

-- APPOINTMENT: doctor schedule queries
CREATE INDEX idx_appt_staff
    ON APPOINTMENT (staff_id);

-- APPOINTMENT: status filtering (e.g. today's CONFIRMED appointments)
CREATE INDEX idx_appt_status
    ON APPOINTMENT (status);

-- QUEUE_ENTRY: check-in lookup by appointment
CREATE INDEX idx_queue_appt
    ON QUEUE_ENTRY (appointment_id);

-- QUEUE_ENTRY: live queue board filtered by status
CREATE INDEX idx_queue_status
    ON QUEUE_ENTRY (status);

-- MEDICAL_RECORD: full patient history lookup
CREATE INDEX idx_mr_patient
    ON MEDICAL_RECORD (patient_id);

-- MEDICAL_RECORD: records per appointment
CREATE INDEX idx_mr_appt
    ON MEDICAL_RECORD (appointment_id);

-- NOTIFICATION: notifications per appointment
CREATE INDEX idx_notif_appt
    ON NOTIFICATION (appointment_id);

-- AUDIT_LOG: date-range filtering for admin reports
CREATE INDEX idx_audit_timestamp
    ON AUDIT_LOG (log_timestamp);

-- AUDIT_LOG: per-user activity history
CREATE INDEX idx_audit_user
    ON AUDIT_LOG (user_id);

-- Verify all indexes
SELECT index_name, table_name, uniqueness
FROM user_indexes
WHERE table_name IN (
    'TIMESLOT','APPOINTMENT','QUEUE_ENTRY',
    'MEDICAL_RECORD','NOTIFICATION','AUDIT_LOG'
)
ORDER BY table_name, index_name;
