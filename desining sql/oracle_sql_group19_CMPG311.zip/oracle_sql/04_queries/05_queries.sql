-- =============================================================================
-- UBUNTU CAMPUS CLINIC — APPOINTMENT SYSTEM
-- Group 19 | CMPG 311 | DBMS Module | Physical Design
-- File: 05_queries.sql
-- Purpose: All 11 rubric query categories demonstrated
-- =============================================================================

-- =============================================================================
-- CATEGORY 1: Business Information Queries (10 marks)
-- Queries based on actual clinic information requirements
-- =============================================================================

-- Q1.1: All patients and their upcoming confirmed appointments
SELECT
    p.student_number,
    p.first_name || ' ' || p.last_name   AS patient_name,
    a.appointment_id,
    a.status,
    a.booking_type,
    a.priority,
    t.slot_date,
    t.start_time,
    s.first_name || ' ' || s.last_name   AS doctor
FROM PATIENT      p
JOIN APPOINTMENT  a ON a.patient_id = p.patient_id
JOIN TIMESLOT     t ON t.slot_id    = a.slot_id
JOIN STAFF        s ON s.staff_id   = a.staff_id
WHERE a.status IN ('SCHEDULED', 'CONFIRMED')
ORDER BY t.slot_date, t.start_time;

-- Q1.2: Today's queue board — who is currently waiting or in progress
SELECT
    q.queue_entry_id,
    p.student_number,
    p.first_name || ' ' || p.last_name  AS patient_name,
    q.status                             AS queue_status,
    a.priority,
    q.room_number,
    s.first_name || ' ' || s.last_name  AS attending_doctor
FROM QUEUE_ENTRY  q
JOIN APPOINTMENT  a ON a.appointment_id = q.appointment_id
JOIN PATIENT      p ON p.patient_id     = a.patient_id
JOIN TIMESLOT     t ON t.slot_id        = a.slot_id
JOIN STAFF        s ON s.staff_id       = a.staff_id
WHERE t.slot_date = TRUNC(SYSDATE)
  AND q.status IN ('WAITING', 'IN_PROGRESS')
ORDER BY q.checked_in_at;

-- Q1.3: All medical records with full patient and doctor details
SELECT
    mr.medical_record_id,
    p.student_number,
    p.first_name || ' ' || p.last_name   AS patient_name,
    mr.diagnosis,
    mr.prescription,
    mr.treatment_notes,
    mr.created_at,
    s.first_name || ' ' || s.last_name   AS treating_doctor,
    d.specialisation
FROM MEDICAL_RECORD  mr
JOIN PATIENT         p  ON p.patient_id  = mr.patient_id
JOIN APPOINTMENT     a  ON a.appointment_id = mr.appointment_id
JOIN STAFF           s  ON s.staff_id    = a.staff_id
JOIN DOCTOR          d  ON d.staff_id    = s.staff_id
ORDER BY mr.created_at DESC;

-- Q1.4: All available timeslots for the next 7 days
SELECT
    slot_id,
    TO_CHAR(slot_date, 'Day DD Mon YYYY') AS slot_date,
    start_time,
    end_time
FROM TIMESLOT
WHERE slot_date BETWEEN TRUNC(SYSDATE) AND TRUNC(SYSDATE) + 7
  AND is_available = 1
ORDER BY slot_date, start_time;

-- Q1.5: Patients who have not given consent
SELECT
    patient_id,
    student_number,
    first_name || ' ' || last_name   AS full_name,
    email,
    registration_date
FROM PATIENT
WHERE consent_given = 0
ORDER BY registration_date;

-- =============================================================================
-- CATEGORY 2: Query Limitations — Rows & Columns (4 marks)
-- Restricting output using WHERE, FETCH FIRST, and column selection
-- =============================================================================

-- Q2.1: Show only the first 3 patients registered (row limit)
SELECT patient_id, student_number, first_name, last_name
FROM PATIENT
ORDER BY registration_date
FETCH FIRST 3 ROWS ONLY;

-- Q2.2: Show only specific columns from APPOINTMENT (column limit)
SELECT appointment_id, patient_id, status, priority
FROM APPOINTMENT;

-- Q2.3: Latest 5 audit log entries (top N rows)
SELECT audit_log_id, action, table_affected, log_timestamp
FROM AUDIT_LOG
ORDER BY log_timestamp DESC
FETCH FIRST 5 ROWS ONLY;

-- Q2.4: Only URGENT appointments — rows filtered by business condition
SELECT appointment_id, patient_id, staff_id, booking_type, status
FROM APPOINTMENT
WHERE priority = 'URGENT';

-- =============================================================================
-- CATEGORY 3: Sorting Operations (4 marks)
-- ORDER BY — ascending, descending, multiple columns
-- =============================================================================

-- Q3.1: Patients sorted alphabetically by last name
SELECT student_number, first_name, last_name, city
FROM PATIENT
ORDER BY last_name ASC, first_name ASC;

-- Q3.2: Appointments sorted by date descending (most recent first)
SELECT appointment_id, patient_id, status, booking_type
FROM APPOINTMENT   a
JOIN TIMESLOT      t ON t.slot_id = a.slot_id
ORDER BY t.slot_date DESC, t.start_time DESC;

-- Q3.3: Staff sorted by department then role then surname
SELECT department_id, role, last_name, first_name, email
FROM STAFF
ORDER BY department_id ASC, role ASC, last_name ASC;

-- Q3.4: Audit log sorted by most recent action per user
SELECT user_id, action, table_affected, log_timestamp
FROM AUDIT_LOG
ORDER BY user_id ASC, log_timestamp DESC;

-- =============================================================================
-- CATEGORY 4: LIKE, AND, OR Operators (4 marks)
-- =============================================================================

-- Q4.1: LIKE — patients whose last name starts with 'M'
SELECT student_number, first_name, last_name, email
FROM PATIENT
WHERE last_name LIKE 'M%';

-- Q4.2: LIKE — staff emails from the ubuntuclinic domain
SELECT first_name, last_name, role, email
FROM STAFF
WHERE email LIKE '%@ubuntuclinic.ac.za';

-- Q4.3: AND — completed appointments with URGENT priority
SELECT appointment_id, patient_id, status, priority, booking_type
FROM APPOINTMENT
WHERE status = 'COMPLETED'
  AND priority = 'URGENT';

-- Q4.4: OR — patients living in Potchefstroom or Mahikeng
SELECT student_number, first_name, last_name, city, postal_code
FROM PATIENT
WHERE city = 'Potchefstroom'
   OR city = 'Mahikeng'
ORDER BY city, last_name;

-- Q4.5: LIKE + AND combined — active doctor accounts
SELECT ua.username, ua.role, ua.status, s.last_name
FROM USER_ACCOUNT ua
JOIN STAFF        s ON s.staff_id = ua.staff_id
WHERE ua.role = 'DOCTOR'
  AND ua.username LIKE 'doctor_%'
  AND ua.status = 'ACTIVE';

-- =============================================================================
-- CATEGORY 5: Variables & Character Functions (4 marks)
-- UPPER, LOWER, SUBSTR, LENGTH, CONCAT, TRIM, INITCAP
-- =============================================================================

-- Q5.1: UPPER — patient names in uppercase
SELECT student_number,
       UPPER(first_name)  AS first_upper,
       UPPER(last_name)   AS last_upper,
       UPPER(email)       AS email_upper
FROM PATIENT;

-- Q5.2: LOWER — staff email addresses in lowercase
SELECT LOWER(first_name || ' ' || last_name)  AS staff_name_lower,
       LOWER(email)                            AS email_lower,
       role
FROM STAFF;

-- Q5.3: SUBSTR and LENGTH — extract student number prefix and show length
SELECT student_number,
       SUBSTR(student_number, 1, 4)   AS number_prefix,
       LENGTH(student_number)          AS number_length,
       first_name,
       last_name
FROM PATIENT;

-- Q5.4: INITCAP and CONCAT — formatted full names
SELECT INITCAP(CONCAT(CONCAT(first_name, ' '), last_name))  AS formatted_name,
       INITCAP(city)                                          AS formatted_city,
       email
FROM PATIENT;

-- Q5.5: TRIM — clean whitespace from contact numbers and REPLACE
SELECT patient_id,
       TRIM(contact_number)                        AS trimmed_contact,
       REPLACE(contact_number, '0', '+27', 1, 1)  AS intl_contact
FROM PATIENT;

-- Q5.6: Using a variable (substitution variable)
-- In Oracle SQL Developer, use: DEFINE v_city = 'Potchefstroom'
DEFINE v_city = 'Potchefstroom'
SELECT student_number, first_name, last_name, city
FROM PATIENT
WHERE city = '&v_city';

-- =============================================================================
-- CATEGORY 6: Rounding & Truncation (4 marks)
-- ROUND, TRUNC, CEIL, FLOOR
-- =============================================================================

-- Q6.1: ROUND — patient age in years rounded to nearest whole number
SELECT student_number,
       first_name || ' ' || last_name                        AS full_name,
       date_of_birth,
       ROUND(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12, 0) AS age_years_rounded
FROM PATIENT
ORDER BY age_years_rounded;

-- Q6.2: TRUNC — today's date (time portion removed)
SELECT
    SYSDATE                             AS current_datetime,
    TRUNC(SYSDATE)                      AS today_date_only,
    TRUNC(SYSDATE, 'MM')               AS first_of_month,
    TRUNC(SYSDATE, 'YYYY')             AS first_of_year
FROM DUAL;

-- Q6.3: ROUND and TRUNC on numeric values — slot duration in hours
SELECT slot_id,
       slot_date,
       start_time,
       end_time,
       ROUND(30 / 60, 2)              AS slot_duration_hrs_rounded,
       TRUNC(30 / 60, 1)             AS slot_duration_hrs_truncated
FROM TIMESLOT
WHERE ROWNUM <= 5;

-- Q6.4: CEIL and FLOOR on age calculation
SELECT student_number,
       first_name || ' ' || last_name                          AS full_name,
       CEIL(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12)      AS age_ceil,
       FLOOR(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12)     AS age_floor
FROM PATIENT;

-- =============================================================================
-- CATEGORY 7: Date Functions (4 marks)
-- SYSDATE, ADD_MONTHS, MONTHS_BETWEEN, TO_DATE, TO_CHAR, LAST_DAY, NEXT_DAY
-- =============================================================================

-- Q7.1: SYSDATE — current date and time
SELECT
    SYSDATE                              AS right_now,
    TRUNC(SYSDATE)                       AS today,
    SYSDATE + 1                          AS tomorrow,
    SYSDATE - 7                          AS one_week_ago
FROM DUAL;

-- Q7.2: MONTHS_BETWEEN and TO_CHAR — patient age and formatted DOB
SELECT student_number,
       first_name || ' ' || last_name                             AS full_name,
       TO_CHAR(date_of_birth, 'DD Month YYYY')                    AS dob_formatted,
       FLOOR(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12)        AS age_years,
       MOD(FLOOR(MONTHS_BETWEEN(SYSDATE, date_of_birth)), 12)    AS age_months_remainder
FROM PATIENT;

-- Q7.3: ADD_MONTHS — follow-up date 1 and 3 months after appointment
SELECT
    a.appointment_id,
    p.first_name || ' ' || p.last_name         AS patient_name,
    t.slot_date                                  AS appointment_date,
    ADD_MONTHS(t.slot_date, 1)                  AS followup_1_month,
    ADD_MONTHS(t.slot_date, 3)                  AS followup_3_months
FROM APPOINTMENT  a
JOIN TIMESLOT     t ON t.slot_id    = a.slot_id
JOIN PATIENT      p ON p.patient_id = a.patient_id
WHERE a.status = 'COMPLETED';

-- Q7.4: LAST_DAY and NEXT_DAY — scheduling helpers
SELECT
    SYSDATE                             AS today,
    LAST_DAY(SYSDATE)                  AS last_day_of_month,
    NEXT_DAY(SYSDATE, 'MONDAY')        AS next_monday
FROM DUAL;

-- Q7.5: TO_DATE — insert and filter using date conversion
SELECT appointment_id, status, booking_type
FROM APPOINTMENT a
JOIN TIMESLOT    t ON t.slot_id = a.slot_id
WHERE t.slot_date >= TO_DATE('2025-01-01', 'YYYY-MM-DD');

-- Q7.6: TO_CHAR — format audit log timestamps for a report
SELECT
    audit_log_id,
    TO_CHAR(log_timestamp, 'DD/MM/YYYY HH24:MI:SS')  AS log_time_formatted,
    action,
    table_affected,
    ip_address
FROM AUDIT_LOG
ORDER BY log_timestamp DESC;

-- =============================================================================
-- CATEGORY 8: Aggregate Functions (4 marks)
-- COUNT, SUM, AVG, MAX, MIN
-- =============================================================================

-- Q8.1: COUNT — total number of patients registered
SELECT COUNT(*)  AS total_patients FROM PATIENT;

-- Q8.2: COUNT — total appointments per status
SELECT status, COUNT(*) AS total
FROM APPOINTMENT
GROUP BY status;

-- Q8.3: AVG — average patient age
SELECT ROUND(AVG(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12), 1)  AS avg_age_years
FROM PATIENT;

-- Q8.4: MAX and MIN — oldest and youngest patient
SELECT
    MAX(FLOOR(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12))  AS oldest_age,
    MIN(FLOOR(MONTHS_BETWEEN(SYSDATE, date_of_birth) / 12))  AS youngest_age
FROM PATIENT;

-- Q8.5: COUNT with DISTINCT — number of distinct cities where patients live
SELECT COUNT(DISTINCT city)  AS distinct_cities FROM PATIENT;

-- Q8.6: COUNT — notifications by channel and status
SELECT channel, status, COUNT(*) AS total
FROM NOTIFICATION
GROUP BY channel, status
ORDER BY channel, status;

-- =============================================================================
-- CATEGORY 9: GROUP BY & HAVING (4 marks)
-- =============================================================================

-- Q9.1: GROUP BY — appointments per doctor
SELECT
    s.first_name || ' ' || s.last_name   AS doctor_name,
    COUNT(a.appointment_id)               AS total_appointments
FROM STAFF        s
JOIN APPOINTMENT  a ON a.staff_id = s.staff_id
WHERE s.role = 'DOCTOR'
GROUP BY s.staff_id, s.first_name, s.last_name
ORDER BY total_appointments DESC;

-- Q9.2: GROUP BY + HAVING — cities with more than 2 patients
SELECT city, COUNT(*) AS patient_count
FROM PATIENT
GROUP BY city
HAVING COUNT(*) >= 2
ORDER BY patient_count DESC;

-- Q9.3: GROUP BY — appointments per booking type
SELECT booking_type, COUNT(*) AS total, COUNT(DISTINCT patient_id) AS unique_patients
FROM APPOINTMENT
GROUP BY booking_type
ORDER BY total DESC;

-- Q9.4: GROUP BY + HAVING — doctors with more than 1 appointment
SELECT
    a.staff_id,
    s.last_name      AS doctor_surname,
    COUNT(*)          AS appt_count
FROM APPOINTMENT  a
JOIN STAFF        s ON s.staff_id = a.staff_id
GROUP BY a.staff_id, s.last_name
HAVING COUNT(*) > 1
ORDER BY appt_count DESC;

-- Q9.5: GROUP BY — audit actions per user account
SELECT
    al.user_id,
    ua.username,
    al.action,
    COUNT(*) AS times_performed
FROM AUDIT_LOG    al
JOIN USER_ACCOUNT ua ON ua.user_account_id = al.user_id
GROUP BY al.user_id, ua.username, al.action
ORDER BY al.user_id, times_performed DESC;

-- =============================================================================
-- CATEGORY 10: Joins (5 marks)
-- INNER JOIN, LEFT JOIN, RIGHT JOIN, SELF JOIN
-- =============================================================================

-- Q10.1: INNER JOIN — patients with their appointments and timeslot details
SELECT
    p.student_number,
    p.first_name || ' ' || p.last_name  AS patient_name,
    a.status,
    a.priority,
    t.slot_date,
    t.start_time
FROM PATIENT      p
INNER JOIN APPOINTMENT  a ON a.patient_id = p.patient_id
INNER JOIN TIMESLOT     t ON t.slot_id    = a.slot_id
ORDER BY t.slot_date;

-- Q10.2: INNER JOIN (5 tables) — full appointment detail
SELECT
    p.student_number,
    p.first_name || ' ' || p.last_name    AS patient_name,
    s.first_name || ' ' || s.last_name    AS doctor_name,
    d.specialisation,
    dept.department_name,
    a.status,
    a.booking_type,
    t.slot_date,
    t.start_time
FROM APPOINTMENT  a
INNER JOIN PATIENT     p    ON p.patient_id     = a.patient_id
INNER JOIN STAFF       s    ON s.staff_id       = a.staff_id
INNER JOIN DOCTOR      d    ON d.staff_id       = s.staff_id
INNER JOIN DEPARTMENT  dept ON dept.department_id = s.department_id
INNER JOIN TIMESLOT    t    ON t.slot_id        = a.slot_id;

-- Q10.3: LEFT JOIN — all patients, including those with NO appointments
SELECT
    p.student_number,
    p.first_name || ' ' || p.last_name  AS patient_name,
    p.city,
    a.appointment_id,
    a.status
FROM PATIENT      p
LEFT JOIN APPOINTMENT  a ON a.patient_id = p.patient_id
ORDER BY p.last_name;

-- Q10.4: LEFT JOIN — all timeslots including unbooked ones
SELECT
    t.slot_id,
    t.slot_date,
    t.start_time,
    t.is_available,
    a.appointment_id,
    a.status
FROM TIMESLOT    t
LEFT JOIN APPOINTMENT  a ON a.slot_id = t.slot_id
ORDER BY t.slot_date, t.start_time;

-- Q10.5: SELF JOIN — DEPARTMENT head names (DEPARTMENT joined to STAFF)
SELECT
    d.department_id,
    d.department_name,
    s.first_name || ' ' || s.last_name  AS head_of_department,
    s.role
FROM DEPARTMENT  d
LEFT JOIN STAFF  s ON s.staff_id = d.head_staff_id
ORDER BY d.department_name;

-- Q10.6: JOIN with QUEUE_ENTRY — completed consultations with timing
SELECT
    p.student_number,
    p.first_name || ' ' || p.last_name    AS patient_name,
    q.consult_start_time,
    q.consult_end_time,
    q.room_number,
    s.first_name || ' ' || s.last_name    AS doctor_name,
    mr.diagnosis
FROM QUEUE_ENTRY    q
JOIN APPOINTMENT    a   ON a.appointment_id  = q.appointment_id
JOIN PATIENT        p   ON p.patient_id      = a.patient_id
JOIN STAFF          s   ON s.staff_id        = a.staff_id
LEFT JOIN MEDICAL_RECORD mr ON mr.appointment_id = a.appointment_id
WHERE q.status = 'COMPLETED';

-- =============================================================================
-- CATEGORY 11: Sub-queries (5 marks)
-- Scalar, inline view, correlated, EXISTS, IN
-- =============================================================================

-- Q11.1: IN subquery — patients who have had a COMPLETED appointment
SELECT student_number, first_name, last_name, email
FROM PATIENT
WHERE patient_id IN (
    SELECT DISTINCT patient_id
    FROM APPOINTMENT
    WHERE status = 'COMPLETED'
)
ORDER BY last_name;

-- Q11.2: NOT IN subquery — patients who have NEVER had an appointment
SELECT student_number, first_name, last_name, city
FROM PATIENT
WHERE patient_id NOT IN (
    SELECT DISTINCT patient_id
    FROM APPOINTMENT
)
ORDER BY last_name;

-- Q11.3: Scalar subquery — each patient's most recent appointment date
SELECT
    p.student_number,
    p.first_name || ' ' || p.last_name  AS patient_name,
    (
        SELECT MAX(t.slot_date)
        FROM APPOINTMENT a2
        JOIN TIMESLOT    t  ON t.slot_id = a2.slot_id
        WHERE a2.patient_id = p.patient_id
    )                                   AS last_appointment_date
FROM PATIENT p
ORDER BY last_appointment_date DESC NULLS LAST;

-- Q11.4: Correlated subquery — patients whose most recent appointment was URGENT
SELECT student_number, first_name, last_name
FROM PATIENT p
WHERE EXISTS (
    SELECT 1
    FROM APPOINTMENT a
    WHERE a.patient_id = p.patient_id
      AND a.priority   = 'URGENT'
      AND a.status     = 'COMPLETED'
);

-- Q11.5: Inline view subquery — average appointments per doctor, ranked
SELECT doctor_name, appt_count,
       RANK() OVER (ORDER BY appt_count DESC)  AS rank_by_appts
FROM (
    SELECT s.first_name || ' ' || s.last_name  AS doctor_name,
           COUNT(a.appointment_id)              AS appt_count
    FROM STAFF        s
    JOIN APPOINTMENT  a ON a.staff_id = s.staff_id
    WHERE s.role = 'DOCTOR'
    GROUP BY s.staff_id, s.first_name, s.last_name
) doctor_counts
ORDER BY appt_count DESC;

-- Q11.6: Subquery in HAVING — departments whose staff have more than
--        the average number of appointments across all staff
SELECT s.department_id,
       d.department_name,
       COUNT(a.appointment_id) AS dept_appointments
FROM STAFF       s
JOIN APPOINTMENT a    ON a.staff_id       = s.staff_id
JOIN DEPARTMENT  d    ON d.department_id  = s.department_id
GROUP BY s.department_id, d.department_name
HAVING COUNT(a.appointment_id) > (
    SELECT AVG(appt_count)
    FROM (
        SELECT COUNT(*) AS appt_count
        FROM APPOINTMENT
        GROUP BY staff_id
    )
)
ORDER BY dept_appointments DESC;
