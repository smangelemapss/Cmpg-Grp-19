# Ubuntu Campus Clinic — Oracle SQL Submission
## Group 19 | CMPG 311 | DBMS Module | Physical Design

---

## File Structure

```
oracle_sql/
├── 00_RUN_ALL.sql                  ← START HERE — runs everything in order
│
├── 01_DDL/
│   ├── 01_create_tables.sql        ← 12 tables, all constraints (18 marks)
│   ├── 02_create_indexes.sql       ← 12 indexes (2 marks)
│   └── 03_create_views.sql         ← 4 views (4 marks)
│
├── 02_DML/
│   └── 04_insert_data.sql          ← All 12 tables seeded (4 marks)
│
└── 04_queries/
    └── 05_queries.sql              ← All 11 query categories (52 marks)
```

---

## Rubric Coverage

| Rubric Item | Marks | File | Status |
|---|---|---|---|
| Tables — correct data types, 3NF, PK/FK, CHECK constraints | 18 | 01_create_tables.sql | ✅ |
| Indexes created | 2 | 02_create_indexes.sql | ✅ |
| Views implemented | 4 | 03_create_views.sql | ✅ |
| Data populated | 4 | 04_insert_data.sql | ✅ |
| Business information queries | 10 | 05_queries.sql Q1.x | ✅ |
| Query limitations (rows & columns) | 4 | 05_queries.sql Q2.x | ✅ |
| Sorting operations | 4 | 05_queries.sql Q3.x | ✅ |
| LIKE, AND, OR operators | 4 | 05_queries.sql Q4.x | ✅ |
| Variables & character functions | 4 | 05_queries.sql Q5.x | ✅ |
| Rounding/truncation | 4 | 05_queries.sql Q6.x | ✅ |
| Date functions | 4 | 05_queries.sql Q7.x | ✅ |
| Aggregate functions | 4 | 05_queries.sql Q8.x | ✅ |
| GROUP BY & HAVING | 4 | 05_queries.sql Q9.x | ✅ |
| Joins | 5 | 05_queries.sql Q10.x | ✅ |
| Sub-queries | 5 | 05_queries.sql Q11.x | ✅ |
| **TOTAL** | **80** | | |

---

## Setup Instructions (Oracle SQL Developer)

### Step 1 — Connect to Oracle
1. Open **Oracle SQL Developer**
2. Create a new connection or use an existing one
3. Connect to your Oracle schema (XE or university-provided)

### Step 2 — Run the master script
1. Go to **File > Open**
2. Navigate to and open `00_RUN_ALL.sql`
3. Press **F5** (Run Script — not F9)
4. Watch the **Script Output** panel at the bottom
5. You should see 12 tables, 12 indexes, 4 views created, and all rows inserted

### Step 3 — Verify setup
After `00_RUN_ALL.sql` completes, you will see a verification table showing row counts for all 12 tables. Expected counts:

| Table | Rows |
|---|---|
| DEPARTMENT | 5 |
| STAFF | 6 |
| DOCTOR | 3 |
| PATIENT | 8 |
| PATIENT_CONTACT | 8 |
| USER_ACCOUNT | 12 |
| TIMESLOT | 12 |
| APPOINTMENT | 8 |
| QUEUE_ENTRY | 3 |
| MEDICAL_RECORD | 3 |
| NOTIFICATION | 8 |
| AUDIT_LOG | 10 |

### Step 4 — Run queries for demonstration
1. Open `04_queries/05_queries.sql`
2. Highlight a single query block (from the comment to the semicolon)
3. Press **F9** (Run Statement) to execute it
4. Results appear in the **Query Result** tab

---

## Database Design — 12 Tables

### Table Relationships

```
DEPARTMENT ──< STAFF ──< DOCTOR
                 │
                 └──< USER_ACCOUNT >── PATIENT
                              │              │
                         AUDIT_LOG    PATIENT_CONTACT

PATIENT ──< APPOINTMENT >── TIMESLOT
                │
                ├──< QUEUE_ENTRY
                ├──< MEDICAL_RECORD
                └──< NOTIFICATION
```

### Normalisation — 3NF Compliance
- **1NF**: All attributes are atomic. Phone numbers in separate PATIENT_CONTACT table. Address split into street, city, postal_code.
- **2NF**: All tables use single-column surrogate PK — no partial dependencies possible.
- **3NF**: DOCTOR table isolates doctor-specific fields (license_number, specialisation) from STAFF — no transitive dependencies.

### Key Constraints
| Constraint | Table | Purpose |
|---|---|---|
| UNIQUE(student_number) | PATIENT | No duplicate registrations |
| UNIQUE(slot_id) | APPOINTMENT | Prevents double-booking at DB level |
| UNIQUE(appointment_id) | QUEUE_ENTRY | One queue entry per appointment |
| UNIQUE(license_number) | DOCTOR | No fraudulent doctor records |
| CHECK(consent IN (0,1)) | PATIENT | POPIA consent enforcement |
| CHECK(patient OR staff IS NOT NULL) | USER_ACCOUNT | No orphan accounts |
| CHECK(patient OR staff IS NOT NULL) | NOTIFICATION | No undeliverable notifications |
| ON DELETE CASCADE | PATIENT_CONTACT | Contacts removed with patient |

---

## Views Summary

| View | Purpose |
|---|---|
| vw_patient_appointments | Patient dashboard — full appointment history |
| vw_daily_queue_board | Today's live queue — for nurses and admin |
| vw_doctor_schedule | Doctor's schedule with patient details |
| vw_audit_trail_summary | POPIA audit log — readable format for admin |

---

## Query Categories Demonstrated (05_queries.sql)

| Category | Queries | Functions/Operators Used |
|---|---|---|
| Q1 — Business queries | Q1.1–Q1.5 | Multi-table joins, WHERE, ORDER BY |
| Q2 — Row/column limits | Q2.1–Q2.4 | FETCH FIRST, column selection, WHERE |
| Q3 — Sorting | Q3.1–Q3.4 | ORDER BY ASC/DESC, multiple columns |
| Q4 — LIKE, AND, OR | Q4.1–Q4.5 | LIKE '%', AND, OR combinations |
| Q5 — Character functions | Q5.1–Q5.6 | UPPER, LOWER, SUBSTR, LENGTH, INITCAP, CONCAT, TRIM, REPLACE, substitution variable |
| Q6 — Rounding/truncation | Q6.1–Q6.4 | ROUND, TRUNC, CEIL, FLOOR |
| Q7 — Date functions | Q7.1–Q7.6 | SYSDATE, ADD_MONTHS, MONTHS_BETWEEN, TO_CHAR, TO_DATE, LAST_DAY, NEXT_DAY |
| Q8 — Aggregates | Q8.1–Q8.6 | COUNT, AVG, MAX, MIN, DISTINCT |
| Q9 — GROUP BY / HAVING | Q9.1–Q9.5 | GROUP BY, HAVING, multi-column grouping |
| Q10 — Joins | Q10.1–Q10.6 | INNER JOIN, LEFT JOIN, 5-table joins, SELF JOIN |
| Q11 — Sub-queries | Q11.1–Q11.6 | IN, NOT IN, scalar, correlated, EXISTS, inline view, RANK() |

---

*Ubuntu Campus Clinic — Group 19 | CMPG 311 | DBMS Module*
